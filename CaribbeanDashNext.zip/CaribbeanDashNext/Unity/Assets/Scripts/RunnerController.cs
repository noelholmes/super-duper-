using UnityEngine;

/// Attach to the player. Requires a CharacterController. Supports keyboard and touch swipes.
[RequireComponent(typeof(CharacterController))]
public class RunnerController : MonoBehaviour
{
    [Header("Movement")]
    [Min(1f)] public float forwardSpeed = 8f;
    [Min(0.5f)] public float laneWidth = 2.2f;
    [Min(1f)] public float laneChangeSpeed = 12f;
    [Min(0.5f)] public float jumpHeight = 2.1f;
    public float gravity = -22f;
    [Min(10f)] public float swipeThreshold = 45f;

    private CharacterController controller;
    private int lane = 1;
    private float verticalVelocity;
    private Vector2 touchStart;

    void Awake() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        if (GameManager.Instance != null && (GameManager.Instance.IsEnded || GameManager.Instance.IsPaused)) return;
        ReadInput();
        float targetX = (lane - 1) * laneWidth;
        float nextX = Mathf.MoveTowards(transform.position.x, targetX, laneChangeSpeed * Time.deltaTime);
        if (controller.isGrounded && verticalVelocity < 0f) verticalVelocity = -1f;
        verticalVelocity += gravity * Time.deltaTime;
        Vector3 motion = new Vector3(nextX - transform.position.x, verticalVelocity * Time.deltaTime, forwardSpeed * Time.deltaTime);
        controller.Move(motion);
    }

    void ReadInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) MoveLane(-1);
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) MoveLane(1);
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) TryJump();
        if (Input.touchCount == 0) return;
        Touch t = Input.GetTouch(0);
        if (t.phase == TouchPhase.Began) touchStart = t.position;
        if (t.phase != TouchPhase.Ended) return;
        Vector2 delta = t.position - touchStart;
        if (delta.magnitude < swipeThreshold) return;
        if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y)) MoveLane(delta.x < 0 ? -1 : 1);
        else if (delta.y > 0) TryJump();
    }

    void MoveLane(int direction) { lane = Mathf.Clamp(lane + direction, 0, 2); }
    void TryJump()
    {
        if (controller.isGrounded) verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.collider.CompareTag("Obstacle")) GameManager.Instance?.EndRun();
    }
}
