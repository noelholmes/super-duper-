using UnityEngine;

/// Optional helper for tile-specific props. TrackSpawner handles normal tile cleanup.
public class TrackTile : MonoBehaviour
{
    [HideInInspector] public Transform player;
}
