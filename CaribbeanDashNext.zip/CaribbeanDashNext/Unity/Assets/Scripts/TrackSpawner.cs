using System.Collections.Generic;
using UnityEngine;

/// Assign tile prefabs with TrackTile. Keep each prefab's length consistent with tileLength.
public class TrackSpawner : MonoBehaviour
{
    public Transform player;
    public GameObject[] trackTilePrefabs;
    [Min(2)] public int tilesOnStart = 6;
    [Min(10f)] public float tileLength = 30f;
    [Min(30f)] public float spawnAheadDistance = 90f;
    private float nextZ;
    private readonly Queue<GameObject> liveTiles = new Queue<GameObject>();

    void Start()
    {
        if (player == null || trackTilePrefabs == null || trackTilePrefabs.Length == 0)
        {
            Debug.LogWarning("TrackSpawner needs a player and at least one track prefab.", this);
            enabled = false;
            return;
        }
        for (int i = 0; i < tilesOnStart; i++) SpawnTile();
    }

    void Update()
    {
        if (player == null) return;
        while (nextZ < player.position.z + spawnAheadDistance) SpawnTile();
        while (liveTiles.Count > 0 && liveTiles.Peek() != null && liveTiles.Peek().transform.position.z + tileLength < player.position.z - 10f)
            Destroy(liveTiles.Dequeue());
    }

    void SpawnTile()
    {
        GameObject prefab = trackTilePrefabs[Random.Range(0, trackTilePrefabs.Length)];
        GameObject tile = Instantiate(prefab, new Vector3(0f, 0f, nextZ), Quaternion.identity);
        liveTiles.Enqueue(tile);
        TrackTile cleanup = tile.GetComponent<TrackTile>();
        if (cleanup != null) cleanup.player = player;
        nextZ += tileLength;
    }
}
