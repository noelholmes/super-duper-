using UnityEngine;

/// Put this on a coin with a trigger collider. The player must have a CharacterController.
public class CoinPickup : MonoBehaviour
{
    public int value = 1;
    private void OnTriggerEnter(Collider other)
    {
        if (!other.GetComponent<RunnerController>()) return;
        if (GameManager.Instance != null) GameManager.Instance.AddCoin(value);
        Destroy(gameObject);
    }
}
