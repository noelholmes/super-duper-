using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// Add to an empty GameObject named GameManager. Assign optional HUD, panels, and buttons in Inspector.
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    [Header("UI (optional)")]
    public Text hudText;
    public GameObject gameOverPanel;
    public Text finalScoreText;
    public Button restartButton;
    public Button pauseButton;

    public int Coins { get; private set; }
    public float Distance { get; private set; }
    public bool IsEnded { get; private set; }
    public bool IsPaused { get; private set; }
    private float startedAt;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        Time.timeScale = 1f;
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        if (restartButton != null) restartButton.onClick.AddListener(RestartRun);
        if (pauseButton != null) pauseButton.onClick.AddListener(TogglePause);
        startedAt = Time.time;
    }

    void Update()
    {
        if (!IsEnded && !IsPaused) Distance = Mathf.Max(Distance, (Time.time - startedAt) * 8f);
        if (hudText != null) hudText.text = $"DISTANCE  {Mathf.FloorToInt(Distance)} m\nCOINS  {Coins}";
    }

    public void AddCoin(int amount = 1)
    {
        if (!IsEnded) Coins += Mathf.Max(1, amount);
    }

    public void EndRun()
    {
        if (IsEnded) return;
        IsEnded = true;
        IsPaused = false;
        Time.timeScale = 0f;
        if (finalScoreText != null) finalScoreText.text = $"RUN OVER\nDistance: {Mathf.FloorToInt(Distance)} m\nCoins: {Coins}";
        if (gameOverPanel != null) gameOverPanel.SetActive(true);
    }

    public void TogglePause()
    {
        if (IsEnded) return;
        IsPaused = !IsPaused;
        Time.timeScale = IsPaused ? 0f : 1f;
    }

    public void RestartRun()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void OnDestroy()
    {
        if (Instance == this) Instance = null;
        Time.timeScale = 1f;
    }
}
