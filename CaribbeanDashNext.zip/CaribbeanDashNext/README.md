# Caribbean Dash — Phone-first prototype pack

This package contains two things:

1. `BrowserDemo/index.html` — a touch-friendly playable gameplay sketch. Open it in a mobile browser after hosting it or opening the file locally. It is a 2D canvas mock-up used to test the runner loop, not the final 3D game.
2. `Unity/Assets/Scripts/` — updated Unity C# scripts for the eventual 3D mobile build.

## Best next step with phone-only access

- Start with the browser demo to try the gameplay idea and tune the feel.
- To make a true 3D Unity app, you will need access to a compatible computer running Unity Editor, either your own, a trusted developer's machine, or a cloud/remote desktop setup. A phone alone is not a practical way to assemble, profile, and sign a full Unity mobile game.
- Avoid paying for a full team until a playable prototype has been tested with a few people.

## Unity setup (when a computer is available)

1. Create a Unity 3D project using a supported Unity LTS version (URP is a good option).
2. Copy `Unity/Assets/Scripts/` into the project's `Assets/Scripts/` folder.
3. Create a ground/track prefab and place it in the scene; ensure each tile prefab is the same length as `TrackSpawner.tileLength` (default 30 units).
4. Add a capsule player at `(0, 1, 0)`, add a `CharacterController` and `RunnerController`, and position a camera behind and above the player.
5. Add a `GameManager` object and `GameManager.cs`. Optional: wire UI Text, game-over panel, restart and pause buttons in the Inspector.
6. Add a `TrackSpawner` object; assign the player and track tile prefab(s).
7. Make obstacles with colliders tagged `Obstacle`. Make coins with trigger colliders and `CoinPickup.cs`.
8. Test keyboard controls in the Editor, then touch controls on devices. If using the new Input System only, configure Active Input Handling for compatibility or migrate input handling.

## Prototype limitations

- The browser demo is a visual gameplay sketch; it is not a 3D Unity build and its simple collision logic is only for early testing.
- The Unity scripts are a source-code starter, not a complete Unity project, APK, or iOS app. Scene setup, art, animations, sound, UI polish, performance testing, analytics, consent/privacy flows, store metadata, and platform review remain.
- For iOS distribution, expect to need a Mac with compatible Xcode for final build/signing. Check current Google Play and Apple developer requirements before release.
